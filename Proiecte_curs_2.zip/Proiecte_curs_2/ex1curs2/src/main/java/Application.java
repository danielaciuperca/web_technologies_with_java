import configuration.ProjectConfiguration;
import musicstore.Album;
import musicstore.Guitar;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Application {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = //step 3 - make Spring use that @Configuration class
                new AnnotationConfigApplicationContext(ProjectConfiguration.class);

        Album album1 = new Album(); //an Album instance NOT in the Spring context
        System.out.println(album1.getArtist());

        Album album2 = context.getBean(Album.class); //getting a reference of a bean by type (Album)
        System.out.println(album2.getArtist());

        album2.setArtist("Led Zepellin");
        System.out.println(album2.getArtist());

        Album album3 = context.getBean(Album.class); //getting a reference of a bean by type (Album)
        System.out.println(album3.getArtist());

        String greeting = context.getBean(String.class);
        System.out.println(greeting);

//        Guitar guitar = context.getBean(Guitar.class); //ambiguity issue

        Guitar guitar1 = context.getBean("classicalGuitar", Guitar.class);//getting a reference of a bean by name (classicalGuitar)
        System.out.println("Classical guitar brand: " + guitar1.getBrand());

        Guitar guitar2 = context.getBean("electricGuitar", Guitar.class);
        System.out.println("Electric guitar brand: " + guitar2.getBrand());
    }

}

package configuration;

import musicstore.Album;
import musicstore.Artist;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ProjectConfiguration {

    @Bean
    public Artist artist(){
        Artist artist = new Artist();
        artist.setName("Debussy");
        return artist;
    }

    @Bean
    public Album album(Artist artist) { //autowiring using the parameters of the @Bean method with DI
        Album album = new Album();
        album.setArtist(artist);  //Spring injects the artist bean from above in the parameter
        return album;
    }
}

package service;

import model.musicstore.Album;
import org.springframework.stereotype.Service;

@Service
public class AlbumService {

    public void create(Album album) {
        //omitted code - call to a repository
        System.out.println("Album " + album + " was created in the database ");
    }
}

import configuration.ProjectConfiguration;
import musicstore.Album;
import musicstore.Guitar;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Application {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(ProjectConfiguration.class);

        System.out.println("Spring context was created");
        Album album1 = context.getBean(Album.class);
        album1.setArtist("Metallica");
        System.out.println(album1.hashCode() + " has artist: " + album1.getArtist());

        Album album2 = context.getBean(Album.class);
        System.out.println(album2.hashCode() + " has artist: " + album2.getArtist());

        Guitar guitar1 = new Guitar();
        guitar1.setBrand("Fender");
        System.out.println(guitar1.hashCode() + " has brand: " + guitar1.getBrand());

        Guitar guitar2 = new Guitar();
        guitar2.setBrand("Yamaha");
        System.out.println(guitar2.hashCode() + " has brand: " + guitar2.getBrand());
    }
}

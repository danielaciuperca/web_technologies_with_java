import configuration.ProjectConfiguration;
import musicstore.Store;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Application {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(ProjectConfiguration.class);

        System.out.println("Spring context was created");

        Store store1 = context.getBean(Store.class);
        System.out.println(store1.hashCode() + " has name: " + store1.getName());

        Store store2 = context.getBean(Store.class);
        System.out.println(store2.hashCode() + " has name: " + store2.getName());
    }
}

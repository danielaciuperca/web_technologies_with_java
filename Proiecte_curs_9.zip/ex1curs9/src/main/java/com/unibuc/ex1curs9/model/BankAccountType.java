package com.unibuc.ex1curs9.model;

public enum BankAccountType {
    DEBIT, SAVINGS
}

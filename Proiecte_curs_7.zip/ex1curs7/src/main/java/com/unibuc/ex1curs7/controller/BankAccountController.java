package com.unibuc.ex1curs7.controller;

import com.unibuc.ex1curs7.model.BankAccount;
import com.unibuc.ex1curs7.model.BankAccountType;
import com.unibuc.ex1curs7.service.BankAccountService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/bankAccounts")//this is the root url for all requests mapped to the methods of this controller
public class BankAccountController {

    private BankAccountService bankAccountService;

    public BankAccountController(BankAccountService bankAccountService) {
        this.bankAccountService = bankAccountService;
    }

    @PostMapping//this will result in the POST /bankAccounts url
    public ResponseEntity<BankAccount> createBankAccount(@RequestBody BankAccount bankAccount) {
        BankAccount createdBankAccount = bankAccountService.createBankAccount(bankAccount);
        return ResponseEntity
                //created() will return the 201 HTTP code and set the Location header on the response, with the url to the newly created bank account
                .created(URI.create("/bankAccounts/" + createdBankAccount.getId()))
                //body() will populate the body of the response with the bank account details
                .body(createdBankAccount);
    }

    @GetMapping("/{id}")//this will result in the GET /bankAccounts/{id} url
    public BankAccount getBankAccount(
            //by default, a path variable is required. we should use it as required
            @PathVariable Long id) {
        return bankAccountService.getBankAccount(id);
    }

    /*this will result in various possible urls:
        GET /bankAccounts
        GET /bankAccounts?type=DEBIT
        GET /bankAccounts?type=SAVINGS
        GET /bankAccounts?type=DEBIT&balance=1000
        GET /bankAccounts?type=SAVINGS&balance=500
        GET /bankAccounts?balance=1000
      and so on, depending on the values for the filters. each filter is optional
     */
    @GetMapping
    public List<BankAccount> getAllBankAccounts(
            //by default, a request param is required. for it to be optional, we use required = false
            @RequestParam(required = false) BankAccountType type,
            @RequestParam(required = false) Double balance) {
        return bankAccountService.getBankAccountsBy(type, balance);
    }
}

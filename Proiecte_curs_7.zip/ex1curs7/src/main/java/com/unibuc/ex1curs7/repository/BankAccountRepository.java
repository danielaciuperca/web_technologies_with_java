package com.unibuc.ex1curs7.repository;

import com.unibuc.ex1curs7.model.BankAccount;
import com.unibuc.ex1curs7.model.BankAccountType;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;

@Repository
public class BankAccountRepository {
    private List<BankAccount> bankAccounts = new ArrayList<>();

    public BankAccount createBankAccount(BankAccount bankAccount) {
        bankAccount.setId(new Random().nextInt());
        bankAccounts.add(bankAccount);
        return bankAccount;
    }

    public Optional<BankAccount> getBankAccount(Long id) {
        return bankAccounts.stream()
                //we search for the bank account with id matching the id sent in the request
                .filter(bankAccount -> bankAccount.getId() == id)
                .findFirst(); //in case no bank account was found, we return an empty Optional object, to avoid returning null
    }

    public List<BankAccount> getBankAccountsBy(BankAccountType type, Double balance) {
        return bankAccounts.stream()
                .filter(bankAccount -> {
                    if (type!= null) {//we filter by type only if the type was sent in the request
                        if (balance != null) { //we filter by balance only if the balance was sent in the request
                            return type.equals(bankAccount.getType()) && balance == bankAccount.getBalance();
                        } else {
                            return type.equals(bankAccount.getType());
                        }
                    } else {//no filters are sent in the request, all bank accounts should be returned
                        return true;
                    }
                })
                .collect(Collectors.toList());
    }
}

package com.unibuc.ex1curs10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex1curs10ApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.unibuc.recap.service;

import com.unibuc.recap.exception.*;
import com.unibuc.recap.model.*;
import com.unibuc.recap.repository.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.mockito.*;
import org.mockito.junit.jupiter.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class DriverServiceTest {
    @Mock
    private DriverRepository driverRepository;
    @InjectMocks
    private DriverService driverService;

    @Test
    @DisplayName("Create driver - happy flow")
    void createDriver() {
        Driver driver = new Driver("John", "john@gmail.com", "Bucharest");
        Driver savedDriver = new Driver(1,"John", "john@gmail.com", "Bucharest");
        when(driverRepository.getByEmail(any())).thenReturn(Optional.empty());
        when(driverRepository.createDriver(any())).thenReturn(savedDriver);

        Driver result = driverService.createDriver(driver);

        assertEquals(driver.getName(), result.getName());
        assertEquals(driver.getEmail(), result.getEmail());
        assertEquals(driver.getCity(), result.getCity());
        assertEquals(1, result.getId());

        verify(driverRepository).getByEmail(any());
        verify(driverRepository).createDriver(any());
    }

    @Test
    @DisplayName("Create driver - driver with same email already exists")
    void createDriverThrowsException() {
        Driver driver = new Driver("John", "john@gmail.com", "Bucharest");
        Driver savedDriver = new Driver(1,"John", "john@gmail.com", "Bucharest");
        when(driverRepository.getByEmail(any())).thenReturn(Optional.of(savedDriver));

        DuplicateDriverException exception = assertThrows(DuplicateDriverException.class,
                () -> driverService.createDriver(driver));

        assertEquals("A driver with the same email already exists.",
                exception.getMessage());

        verify(driverRepository).getByEmail(any());
        verify(driverRepository, times(0)).createDriver(any());
    }
}
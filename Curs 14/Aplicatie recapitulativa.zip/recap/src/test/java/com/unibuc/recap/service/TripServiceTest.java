package com.unibuc.recap.service;

import com.unibuc.recap.exception.*;
import com.unibuc.recap.model.*;
import com.unibuc.recap.repository.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.mockito.*;
import org.mockito.junit.jupiter.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TripServiceTest {
    @Mock
    private TripRepository tripRepository;
    @Mock
    private DriverService driverService;
    @InjectMocks
    private TripService tripService;

    @Test
    @DisplayName("Create trip - happy flow")
    void createTrip() {
        Trip trip = new Trip("Blv.Dacia 5", "Blv.Unirii 20", 1);
        Trip savedTrip = new Trip(1, "Blv.Dacia 5", "Blv.Unirii 20", 1);
        when(driverService.existsById(trip.getDriverId())).thenReturn(true);
        when(tripRepository.createTrip(any())).thenReturn(savedTrip);

        Trip result = tripService.createTrip(trip);

        assertEquals(trip.getFromAddress(), result.getFromAddress());
        assertEquals(trip.getToAddress(), result.getToAddress());
        assertEquals(trip.getDriverId(), result.getDriverId());
        assertEquals(1, result.getId());

        verify(driverService).existsById(trip.getDriverId());
        verify(tripRepository).createTrip(any());
    }

    @Test
    @DisplayName("Create trip - driver doesn't exist")
    void createTripThrowsException() {
        Trip trip = new Trip("Blv.Dacia 5", "Blv.Unirii 20", 3);
        when(driverService.existsById(trip.getDriverId())).thenReturn(false);

        DriverNotFoundException exception = assertThrows(DriverNotFoundException.class,
                () -> tripService.createTrip(trip));

        assertEquals("The driver with id 3 doesn't exist.", exception.getMessage());

        verify(driverService, times(1)).existsById(trip.getDriverId());
        verify(tripRepository, times(0)).createTrip(any());
    }

    @Test
    @DisplayName("Get trips by driver - driver exists")
    void getByDriverId() {
        Trip trip1 = new Trip(1, "Blv.Dacia 5", "Blv.Unirii 20", 1);
        Trip trip2 = new Trip(2, "Blv.Unirii 20", "Blv.Dacia 5", 1);
        when(tripRepository.getByDriverId(1)).thenReturn(List.of(trip1, trip2));

        List<Trip> result = tripService.getByDriverId(1);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(trip1, result.get(0));
        assertEquals(trip2, result.get(1));

        verify(tripRepository).getByDriverId(1);
    }

    @Test
    @DisplayName("Get trips by driver - driver doesn't exist")
    void getByDriverIdDriverDoesntExist() {
        when(tripRepository.getByDriverId(1)).thenReturn(Collections.emptyList());

        List<Trip> result = tripService.getByDriverId(1);

        assertNotNull(result);
        assertTrue(result.isEmpty());

        verify(tripRepository).getByDriverId(1);
    }
}
package com.unibuc.recap.model;

import javax.validation.constraints.*;

public class Trip {
    private long id;
    private String fromAddress;
    private String toAddress;
    private long driverId;

    public Trip() {
    }

    public Trip(String fromAddress, String toAddress, long driverId) {
        this.fromAddress = fromAddress;
        this.toAddress = toAddress;
        this.driverId = driverId;
    }

    public Trip(long id, String fromAddress, String toAddress, long driverId) {
        this.id = id;
        this.fromAddress = fromAddress;
        this.toAddress = toAddress;
        this.driverId = driverId;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFromAddress() {
        return fromAddress;
    }

    public void setFromAddress(String fromAddress) {
        this.fromAddress = fromAddress;
    }

    public String getToAddress() {
        return toAddress;
    }

    public void setToAddress(String toAddress) {
        this.toAddress = toAddress;
    }

    public long getDriverId() {
        return driverId;
    }

    public void setDriverId(long driverId) {
        this.driverId = driverId;
    }
}

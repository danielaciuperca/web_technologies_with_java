package com.unibuc.recap.service;

import com.unibuc.recap.exception.*;
import com.unibuc.recap.model.*;
import com.unibuc.recap.repository.*;
import org.springframework.stereotype.*;

import java.util.*;

@Service
public class TripService {
    private TripRepository tripRepository;
    private DriverService driverService;

    public TripService(TripRepository tripRepository, DriverService driverService) {
        this.tripRepository = tripRepository;
        this.driverService = driverService;
    }

    public Trip createTrip(Trip trip) {
        if(!driverService.existsById(trip.getDriverId())) {
            throw new DriverNotFoundException(trip.getDriverId());
        }
        return tripRepository.createTrip(trip);
    }

    public List<Trip> getByDriverId(long driverId) {
        return tripRepository.getByDriverId(driverId);
    }
}

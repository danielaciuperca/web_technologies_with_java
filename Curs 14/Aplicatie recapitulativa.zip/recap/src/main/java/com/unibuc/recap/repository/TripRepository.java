package com.unibuc.recap.repository;

import com.unibuc.recap.model.*;
import com.unibuc.recap.model.Driver;
import org.springframework.jdbc.core.*;
import org.springframework.jdbc.support.*;
import org.springframework.stereotype.*;

import java.sql.*;
import java.util.*;

@Repository
public class TripRepository {
    private JdbcTemplate jdbcTemplate;

    public TripRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public Trip createTrip(Trip trip) {
        String sql = "insert into trips values (null, ?, ?, ?)";
        PreparedStatementCreator preparedStatementCreator = connection -> {
            PreparedStatement preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setString(1, trip.getFromAddress());
            preparedStatement.setString(2, trip.getToAddress());
            preparedStatement.setLong(3, trip.getDriverId());
            return preparedStatement;
        };
        GeneratedKeyHolder generatedKeyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(preparedStatementCreator, generatedKeyHolder);

        trip.setId(generatedKeyHolder.getKey().longValue());
        return trip;
    }

    public List<Trip> getByDriverId(long driverId) {
        String sql = "select * from trips t where t.driverId = ?";
        return jdbcTemplate.query(sql, getTripRowMapper(), driverId);
    }

    private RowMapper<Trip> getTripRowMapper() {
        return (resultSet, rowNum) -> {
            Trip trip = new Trip();
            trip.setId(resultSet.getInt("id"));
            trip.setFromAddress(resultSet.getString("fromAddress"));
            trip.setToAddress(resultSet.getString("toAddress"));
            trip.setDriverId(resultSet.getLong("driverId"));
            return trip;
        };
    }
}

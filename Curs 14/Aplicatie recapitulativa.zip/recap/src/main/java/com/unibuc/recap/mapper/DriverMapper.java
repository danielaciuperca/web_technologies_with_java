package com.unibuc.recap.mapper;

import com.unibuc.recap.dto.*;
import com.unibuc.recap.model.*;
import org.springframework.stereotype.*;

@Component
public class DriverMapper {

    public Driver driverDtoToDriver(DriverDto driverDto) {
        return new Driver(driverDto.getName(), driverDto.getEmail(), driverDto.getCity());
    }

    public Driver updateDriverDtoToDriver(UpdateDriverDto updateDriverDto) {
        return new Driver(updateDriverDto.getId(), updateDriverDto.getName(), null, updateDriverDto.getCity());
    }
}

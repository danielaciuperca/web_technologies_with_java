package com.unibuc.recap.mapper;

import com.unibuc.recap.dto.*;
import com.unibuc.recap.model.*;
import org.springframework.stereotype.*;

@Component
public class TripMapper {

    public Trip tripDtoToTrip(TripDto tripDto) {
        return new Trip(tripDto.getFromAddress(), tripDto.getToAddress(), tripDto.getDriverId());
    }
}

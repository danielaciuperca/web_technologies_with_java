package com.unibuc.recap.exception;

public class DriverNotFoundException extends RuntimeException {
    public DriverNotFoundException(long driverId) {
        super("The driver with id " + driverId + " doesn't exist.");
    }
}

package com.unibuc.recap.controller;

import com.unibuc.recap.dto.*;
import com.unibuc.recap.mapper.*;
import com.unibuc.recap.model.*;
import com.unibuc.recap.service.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import javax.validation.*;
import java.util.*;

@RestController
@RequestMapping("/trips")
public class TripController {
    private TripService tripService;
    private TripMapper tripMapper;

    public TripController(TripService tripService, TripMapper tripMapper) {
        this.tripService = tripService;
        this.tripMapper = tripMapper;
    }

    @PostMapping
    public ResponseEntity<Trip> createTrip(
            @RequestBody
            @Valid
                    TripDto tripDto) {
        Trip savedTrip = tripService.createTrip(tripMapper.tripDtoToTrip(tripDto));
        return ResponseEntity
                .created(null)
                .body(savedTrip);
    }

    @GetMapping
    public List<Trip> getTrips(@RequestParam long driverId) {
        return tripService.getByDriverId(driverId);
    }
}

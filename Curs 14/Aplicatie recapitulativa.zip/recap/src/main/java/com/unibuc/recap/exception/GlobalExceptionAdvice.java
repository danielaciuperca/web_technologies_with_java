package com.unibuc.recap.exception;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@ControllerAdvice
public class GlobalExceptionAdvice {

    @ExceptionHandler({DuplicateDriverException.class})
    public ResponseEntity handle(DuplicateDriverException e) {
        return ResponseEntity.badRequest().body(e.getMessage());
    }

    @ExceptionHandler({DriverNotFoundException.class})
    public ResponseEntity handle(DriverNotFoundException e) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
    }
}

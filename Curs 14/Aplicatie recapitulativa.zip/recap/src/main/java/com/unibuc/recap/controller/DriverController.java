package com.unibuc.recap.controller;

import com.unibuc.recap.dto.*;
import com.unibuc.recap.mapper.*;
import com.unibuc.recap.model.*;
import com.unibuc.recap.service.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import javax.validation.*;

@RestController
@RequestMapping("/drivers")
public class DriverController {
    private DriverService driverService;
    private DriverMapper driverMapper;

    public DriverController(DriverService driverService, DriverMapper driverMapper) {
        this.driverService = driverService;
        this.driverMapper = driverMapper;
    }

    @PostMapping
    public ResponseEntity<Driver> createDriver(
            @RequestBody
            @Valid
                    DriverDto driverDto) {
        Driver savedDriver = driverService.createDriver(driverMapper.driverDtoToDriver(driverDto));
        return ResponseEntity
                .created(null)
                .body(savedDriver);
    }

    @PutMapping("/{driverId}")
    public void updateDriver(
            @PathVariable
            int driverId,
            @RequestBody
            @Valid
                UpdateDriverDto updateDriverDto) {
        if(driverId != updateDriverDto.getId()) {
            throw new RuntimeException("Path variable doesn't match the request body id");
        }
        driverService.updateDriver(driverMapper.updateDriverDtoToDriver(updateDriverDto));
    }
}

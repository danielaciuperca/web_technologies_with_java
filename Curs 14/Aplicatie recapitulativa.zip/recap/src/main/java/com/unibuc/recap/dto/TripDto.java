package com.unibuc.recap.dto;

import javax.validation.constraints.*;

public class TripDto {
    @NotBlank
    @Size(max = 200)
    private String fromAddress;
    @NotBlank
    @Size(max = 200)
    private String toAddress;
    @NotNull
    private int driverId;

    public TripDto() {
    }

    public TripDto(@NotBlank @Size(max = 200) String fromAddress, @NotBlank @Size(max = 200) String toAddress, @NotNull int driverId) {
        this.fromAddress = fromAddress;
        this.toAddress = toAddress;
        this.driverId = driverId;
    }

    public String getFromAddress() {
        return fromAddress;
    }

    public void setFromAddress(String fromAddress) {
        this.fromAddress = fromAddress;
    }

    public String getToAddress() {
        return toAddress;
    }

    public void setToAddress(String toAddress) {
        this.toAddress = toAddress;
    }

    public int getDriverId() {
        return driverId;
    }

    public void setDriverId(int driverId) {
        this.driverId = driverId;
    }
}

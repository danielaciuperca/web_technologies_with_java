package com.unibuc.recap.repository;

import com.unibuc.recap.model.Driver;
import org.springframework.jdbc.core.*;
import org.springframework.jdbc.support.*;
import org.springframework.stereotype.*;

import java.sql.*;
import java.util.*;

@Repository
public class DriverRepository {
    private JdbcTemplate jdbcTemplate;

    public DriverRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public Driver createDriver(Driver driver) {
        String sql = "insert into drivers values (null, ?, ?, ?)";
        PreparedStatementCreator preparedStatementCreator = connection -> {
            PreparedStatement preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setString(1, driver.getName());
            preparedStatement.setString(2, driver.getEmail());
            preparedStatement.setString(3, driver.getCity());
            return preparedStatement;
        };
        GeneratedKeyHolder generatedKeyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(preparedStatementCreator, generatedKeyHolder);

        driver.setId(generatedKeyHolder.getKey().longValue());
        return driver;
    }

    public Optional<Driver> getByEmail(String email) {
        String sql = "select * from drivers d where d.email = ?";
        RowMapper<Driver> rowMapper = (resultSet, rowNum) -> {
          Driver driver = new Driver();
          driver.setId(resultSet.getInt("id"));
          driver.setName(resultSet.getString("name"));
          driver.setEmail(resultSet.getString("email"));
          driver.setCity(resultSet.getString("city"));
          return driver;
        };
        List<Driver> result = jdbcTemplate.query(sql, rowMapper, email);
        if(result != null && !result.isEmpty()) {
            return Optional.of(result.get(0));
        } else {
            return Optional.empty();
        }
    }

    public void updateDriver(Driver driver) {
        String sql = "update drivers d set d.name = ?, d.city = ? where d.id = ?";
        jdbcTemplate.update(sql, driver.getName(), driver.getCity(), driver.getId());
    }
}

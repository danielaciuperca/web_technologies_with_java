package com.unibuc.recap.service;

import com.unibuc.recap.exception.*;
import com.unibuc.recap.model.*;
import com.unibuc.recap.repository.*;
import org.springframework.stereotype.*;

import java.util.*;

@Service
public class DriverService {
    private DriverRepository driverRepository;

    public DriverService(DriverRepository driverRepository) {
        this.driverRepository = driverRepository;
    }

    public Driver createDriver(Driver driver) {
        Optional<Driver> driverWithSameEmail = driverRepository.getByEmail(driver.getEmail());
        if(driverWithSameEmail.isPresent()) {
            throw new DuplicateDriverException();
        }
        return driverRepository.createDriver(driver);
    }

    public void updateDriver(Driver driver) {
        driverRepository.updateDriver(driver);
    }
}

package com.unibuc.recap.exception;

public class DuplicateDriverException extends RuntimeException {
    public DuplicateDriverException() {
        super("A driver with the same email already exists.");
    }
}

package com.unibuc.ex2curs5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex2curs5ApplicationTests {

    @Test
    void contextLoads() {
    }

}

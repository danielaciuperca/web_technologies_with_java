package com.unibuc.ex2curs5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex2curs5Application {

    public static void main(String[] args) {
        SpringApplication.run(Ex2curs5Application.class, args);
    }

}

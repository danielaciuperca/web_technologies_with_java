package com.unibuc.ex2curs5.filter;


import com.unibuc.ex2curs5.model.ProductLoggingDetails;
import org.springframework.stereotype.Component;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class LoggingFilter extends HttpFilter {
    private ProductLoggingDetails productLoggingDetails;

    public LoggingFilter(ProductLoggingDetails productLoggingDetails) {
        this.productLoggingDetails = productLoggingDetails;
    }

    @Override
    public void doFilter(HttpServletRequest servletRequest, HttpServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

        filterChain.doFilter(servletRequest, servletResponse);

        System.out.println("=== Logging filter: " + productLoggingDetails);
        if(productLoggingDetails.getProduct() != null) {
            System.out.println("=== Logging filter: Product " + productLoggingDetails.getProduct() +
                    " was created successfully at " + productLoggingDetails.getCreationDateTime());
        }
    }
}

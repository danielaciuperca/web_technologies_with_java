package com.unibuc.ex2curs5.controller;

import com.unibuc.ex2curs5.model.Product;
import com.unibuc.ex2curs5.model.ProductLoggingDetails;
import com.unibuc.ex2curs5.model.ShoppingCart;
import com.unibuc.ex2curs5.service.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;
import java.time.LocalDateTime;
import java.util.List;

@Controller
public class ProductController {

    private ProductService productService;
    private ProductLoggingDetails productLoggingDetails;
    private ShoppingCart shoppingCart;


    public ProductController(ProductService productService, ProductLoggingDetails productLoggingDetails, ShoppingCart shoppingCart) {
        this.productService = productService;
        this.productLoggingDetails = productLoggingDetails;
        this.shoppingCart = shoppingCart;
    }

    @PostMapping(value = "/product")
    public String create(@Valid Product product, BindingResult bindingResult, Model model) {
        if(bindingResult.hasErrors()) {
            return "addProduct";
        }
        productService.create(product);

        productLoggingDetails.setProduct(product);
        productLoggingDetails.setCreationDateTime(LocalDateTime.now());

        addProductsToModel(model);

        addToShoppingCart(product);

        return "addProduct";
    }

    private void addProductsToModel(Model model) {
        model.addAttribute("product", new Product());
        List<Product> products = productService.getAllProducts();
        model.addAttribute("products", products);
    }

    @GetMapping("/product")
    public String get(Model model) {
        model.addAttribute("product", new Product());
        return "addProduct";
    }


    private void addToShoppingCart(@Valid Product product) {
        shoppingCart.getProducts().add(product);
        System.out.println("Shopping cart: " + shoppingCart + " contains " + shoppingCart.getProducts());
    }
}

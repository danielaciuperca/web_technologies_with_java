package com.unibuc.ex1curs5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex1curs5ApplicationTests {

    @Test
    void contextLoads() {
    }

}

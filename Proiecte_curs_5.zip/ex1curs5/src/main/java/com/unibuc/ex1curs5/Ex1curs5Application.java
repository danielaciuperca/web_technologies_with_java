package com.unibuc.ex1curs5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex1curs5Application {

    public static void main(String[] args) {
        SpringApplication.run(Ex1curs5Application.class, args);
    }

}

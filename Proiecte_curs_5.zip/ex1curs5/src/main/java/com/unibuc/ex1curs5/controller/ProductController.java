package com.unibuc.ex1curs5.controller;

import com.unibuc.ex1curs5.model.Product;
import com.unibuc.ex1curs5.service.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;
import java.util.List;

@Controller
public class ProductController {

    private ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @PostMapping(value = "/product")
    public String create(@Valid Product product, BindingResult bindingResult, Model model) {
        if(bindingResult.hasErrors()) {
            return "addProduct";
        }
        productService.create(product);

        addProductsToModel(model);

        return "addProduct";
    }

    private void addProductsToModel(Model model) {
        model.addAttribute("product", new Product());
        List<Product> products = productService.getAllProducts();
        model.addAttribute("products", products);
    }

    @GetMapping("/product")
    public String get(Model model) {
        model.addAttribute("product", new Product());
        return "addProduct";
    }
}

package com.unibuc.ex1curs8.repository;

import com.unibuc.ex1curs8.model.BankAccount;
import com.unibuc.ex1curs8.model.BankAccountType;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;

@Repository
public class BankAccountRepository {
    private List<BankAccount> bankAccounts = new ArrayList<>();

    public BankAccount createBankAccount(BankAccount bankAccount) {
        bankAccount.setId(new Random().nextInt());
        bankAccounts.add(bankAccount);
        return bankAccount;
    }

    public Optional<BankAccount> getBankAccount(Long id) {
        return bankAccounts.stream()
                .filter(bankAccount -> bankAccount.getId() == id)
                .findFirst();
    }

    public List<BankAccount> getBankAccountsBy(BankAccountType type, Double balance) {
        return bankAccounts.stream()
                .filter(bankAccount -> {
                    if (type!= null) {
                        if (balance != null) {
                            return type.equals(bankAccount.getType()) && balance == bankAccount.getBalance();
                        } else {
                            return type.equals(bankAccount.getType());
                        }
                    } else {
                        return true;
                    }
                })
                .collect(Collectors.toList());
    }
}

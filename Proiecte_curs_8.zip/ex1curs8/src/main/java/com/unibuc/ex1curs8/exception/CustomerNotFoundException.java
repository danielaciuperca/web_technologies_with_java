package com.unibuc.ex1curs8.exception;

public class CustomerNotFoundException extends RuntimeException {
}
